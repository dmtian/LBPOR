/*
randombytes/devurandom.h version 20080713
D. J. Bernstein
Public domain.
*/

#ifndef RANDOMBYTES_H
#define RANDOMBYTES_H

namespace nfl {
void randombytes(unsigned char *, unsigned long long);
}

#endif
