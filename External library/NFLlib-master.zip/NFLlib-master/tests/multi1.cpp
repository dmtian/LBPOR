// compilation of this file along with multi0.cpp looks for multiple definitions
#include <nfl.hpp>
