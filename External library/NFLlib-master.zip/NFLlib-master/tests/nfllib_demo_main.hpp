#ifndef DEF_MAIN
#define DEF_MAIN

#include "nfl.hpp"
#include "nfl/params.hpp"

#endif

