// compilation of this file with along multi1.cpp looks for multiple definitions

#include <nfl.hpp>
int main() {
  return 0;
}
